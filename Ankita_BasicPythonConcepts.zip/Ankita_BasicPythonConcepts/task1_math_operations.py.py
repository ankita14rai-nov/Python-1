# Task 1: Perform Basic Mathematical Operations

int_a= int(input("enter the first number: "))

int_b= int(input("enter the second number: "))

addition= int_a + int_b
subtraction= int_a - int_b
multiplication= int_a * int_b
division= int_a / int_b

print("addition is:", addition)
print("subtraction is:", subtraction)
print("multiplication is:", multiplication)
print("division is:", division)
