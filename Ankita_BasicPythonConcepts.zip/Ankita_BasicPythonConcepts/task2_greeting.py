# Task 2: Create a Personalized Greeting

first_name= input("enter the first name: ")
last_name= input("enter the last name: ")

concatenation= first_name +" "+ last_name

print("hello, "+concatenation,"!", "Welcome to the python program.")
